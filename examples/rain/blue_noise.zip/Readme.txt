This 3D image of Blue Noise was taken from the following archive:

	http://momentsingraphics.de/Media/3DBlueNoise/3DAnd4DBlueNoiseTextures.zip

which in turn was generated from the following Public Domain (CC0) Python code:

	https://github.com/MomentsInGraphics/BlueNoise/

Further information on 3D Blue Noise can be found in the author's correspong blog post:

	http://momentsingraphics.de/?p=148